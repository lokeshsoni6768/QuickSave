package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.donation.DonationConfig
import com.example.ui.viewmodel.DownloadViewModel

@Composable
fun SettingsScreen(
    viewModel: DownloadViewModel,
    onNavigateToDonation: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToDebug: () -> Unit,
    modifier: Modifier = Modifier
) {
    val autoDownload by viewModel.autoDownload.collectAsState()
    val wifiOnly by viewModel.wifiOnly.collectAsState()
    val darkTheme by viewModel.darkThemeEnabled.collectAsState()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val localSavePath = remember {
        "${context.getExternalFilesDir(null)}/QuickSave_AI"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "App Constants",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Preferences Group
        Card(modifier = Modifier.fillMaxWidth()) {
            Column {
                SettingsSwitchRow(
                    icon = Icons.Default.FlashOn,
                    title = "Auto Download on Share",
                    subtitle = "Instantly start downloads when link enters",
                    checked = autoDownload,
                    onCheckedChange = { viewModel.toggleAutoDownload(it) }
                )
                HorizontalDivider()
                SettingsSwitchRow(
                    icon = Icons.Default.Wifi,
                    title = "WiFi Only Mode",
                    subtitle = "Postpone downloads until unmetered network connects",
                    checked = wifiOnly,
                    onCheckedChange = { viewModel.toggleWifiOnly(it) }
                )
                HorizontalDivider()
                SettingsSwitchRow(
                    icon = Icons.Default.Brightness4,
                    title = "Dark Cosmic Theme",
                    subtitle = "Cool high contrast dark cyber theme style",
                    checked = darkTheme,
                    onCheckedChange = { viewModel.toggleDarkTheme(it) }
                )
            }
        }

        Text(
            text = "Storage & Assets",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Storage Path Display Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Download Directory Target",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = localSavePath,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Text(
            text = "Gemini AI Engine Status",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Gemini API Configuration Verification Card
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                val geminiKey = try {
                    com.example.BuildConfig.GEMINI_API_KEY
                } catch (e: Throwable) {
                    "NOT_FOUND"
                }
                val isDemoKey = geminiKey.isEmpty() || geminiKey == "MY_GEMINI_API_KEY" || geminiKey == "NOT_FOUND"
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (isDemoKey) Icons.Default.Warning else Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (isDemoKey) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Gemini API Configuration",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Status: " + (if (isDemoKey) "Demonstration Mode (Fallback Active)" else "Production Configured (Active)"),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isDemoKey) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isDemoKey) {
                        "QuickSave AI is currently using standard client sandbox credentials. Features will run using safe local fail-soft fallbacks."
                    } else {
                        "Your customized Gemini integration is active. High-speed, secure server-side AI features are fully ready."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }

        Text(
            text = "Dev Support & Resources",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        // Navigation settings triggers
        Card(modifier = Modifier.fillMaxWidth()) {
            Column {
                SettingsNavigationRow(
                    icon = Icons.Default.Coffee,
                    title = "Support Development & Donate",
                    subtitle = "Preserved Donation Template (${DonationConfig.DEVELOPED_BY})",
                    onClick = onNavigateToDonation
                )
                HorizontalDivider()
                SettingsNavigationRow(
                    icon = Icons.Default.Info,
                    title = "About QuickSave AI App",
                    subtitle = "System metadata and developers",
                    onClick = onNavigateToAbout
                )
                HorizontalDivider()
                SettingsNavigationRow(
                    icon = Icons.Default.NetworkCheck,
                    title = "Cobalt Node Diagnostics",
                    subtitle = "Test DNS latency and JWT status on Cobalt servers",
                    onClick = onNavigateToDebug
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Small Brand Signature clearly shown at bottom
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "QuickSave AI v1.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
            Text(
                text = "${DonationConfig.DEVELOPED_BY} India",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

@Composable
fun SettingsNavigationRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Navigate to page",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
    }
}
