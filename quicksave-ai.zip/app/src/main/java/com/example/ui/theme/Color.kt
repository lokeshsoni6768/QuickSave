package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF101318)
val DarkSurface = Color(0xFF1B2028)
val DarkPrimary = Color(0xFF2DD4BF) // Stunning Teal
val DarkSecondary = Color(0xFF67E8F9) // Cyan secondary
val DarkTertiary = Color(0xFFFB7185) // Rose Red or Pink

val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightPrimary = Color(0xFF0F766E) // Forest Teal
val LightSecondary = Color(0xFF0369A1) // Sky Cyan
val LightTertiary = Color(0xFFBE123C) // Vivid Rose

