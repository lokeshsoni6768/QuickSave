package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MediaDownloaderApp
import com.example.data.model.DownloadItem
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class DownloadViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as MediaDownloaderApp).repository
    private val sharedPrefs = application.getSharedPreferences("quicksave_prefs", Context.MODE_PRIVATE)

    // Observable states
    val allDownloads = repository.allDownloads.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // UI & Settings states
    var autoDownload = MutableStateFlow(sharedPrefs.getBoolean("auto_download", true))
        private set

    var wifiOnly = MutableStateFlow(sharedPrefs.getBoolean("wifi_only", false))
        private set

    var darkThemeEnabled = MutableStateFlow(sharedPrefs.getBoolean("dark_theme", true))
        private set

    // Filtering, Search and Selection status
    val searchQuery = MutableStateFlow("")
    val filterPlatform = MutableStateFlow("All")

    private val _uiMessage = MutableSharedFlow<String>()
    val uiMessage = _uiMessage.asSharedFlow()

    // Filter results dynamically
    val filteredDownloads = combine(
        allDownloads,
        searchQuery,
        filterPlatform
    ) { list, query, platform ->
        list.filter { item ->
            val matchQuery = item.title.contains(query, ignoreCase = true) || item.fileName.contains(query, ignoreCase = true)
            val matchPlatform = platform == "All" || item.platform == platform
            matchQuery && matchPlatform
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
     .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Statistics indicators
    val stats = allDownloads.map { list ->
        val completed = list.filter { it.status == "Completed" }
        val totalSize = completed.sumOf { it.fileSize }
        val count = completed.size

        val platformMap = completed.groupBy { it.platform }.mapValues { it.value.size }

        DownloadStats(
            totalDone = count,
            totalDownloadedBytes = totalSize,
            instagramCount = platformMap["Instagram"] ?: 0,
            youtubeCount = platformMap["YouTube"] ?: 0,
            facebookCount = platformMap["Facebook"] ?: 0,
            twitterCount = platformMap["Twitter"] ?: 0,
            othersCount = (platformMap["Pinterest"] ?: 0) + (platformMap["Vimeo"] ?: 0) + 
                          (platformMap["Reddit"] ?: 0) + (platformMap["Other"] ?: 0)
        )
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
     .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DownloadStats())

    fun triggerDownload(url: String) {
        if (url.isBlank() || !url.startsWith("http")) {
            sendMessage("Invalid media URL shared!")
            return
        }
        viewModelScope.launch {
            try {
                sendMessage("Link Received! Download started in background.")
                repository.enqueueDownload(url, wifiOnly.value)
            } catch (e: Exception) {
                sendMessage("Error: ${e.message}")
            }
        }
    }

    fun deleteDownload(item: DownloadItem, deleteFileFromDisk: Boolean = true) {
        viewModelScope.launch {
            repository.delete(item)
            if (deleteFileFromDisk) {
                try {
                    val file = File(item.filePath)
                    if (file.exists()) {
                        file.delete()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            sendMessage("Item deleted from database.")
        }
    }

    fun toggleAutoDownload(enabled: Boolean) {
        autoDownload.value = enabled
        sharedPrefs.edit().putBoolean("auto_download", enabled).apply()
    }

    fun toggleWifiOnly(enabled: Boolean) {
        wifiOnly.value = enabled
        sharedPrefs.edit().putBoolean("wifi_only", enabled).apply()
    }

    fun toggleDarkTheme(enabled: Boolean) {
        darkThemeEnabled.value = enabled
        sharedPrefs.edit().putBoolean("dark_theme", enabled).apply()
    }

    fun sendMessage(msg: String) {
        viewModelScope.launch {
            _uiMessage.emit(msg)
        }
    }
}

data class DownloadStats(
    val totalDone: Int = 0,
    val totalDownloadedBytes: Long = 0L,
    val instagramCount: Int = 0,
    val youtubeCount: Int = 0,
    val facebookCount: Int = 0,
    val twitterCount: Int = 0,
    val othersCount: Int = 0
)
