package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.model.DownloadItem
import com.example.ui.viewmodel.DownloadViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: DownloadViewModel,
    onPlayMedia: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val searchInput by viewModel.searchQuery.collectAsState()
    val selectedPlatform by viewModel.filterPlatform.collectAsState()
    val downloadsList by viewModel.filteredDownloads.collectAsState()
    val context = LocalContext.current

    val filterOptions = remember { listOf("All", "YouTube", "Instagram", "Facebook", "Twitter", "Other") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 0.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search And Filters Section block
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchInput,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("Search title, file name...") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search icon"
                    )
                },
                trailingIcon = {
                    if (searchInput.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear inquiry"
                            )
                        }
                    }
                },
                shape = MaterialTheme.shapes.medium,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                )
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(filterOptions) { opt ->
                    FilterChip(
                        selected = selectedPlatform == opt,
                        onClick = { viewModel.filterPlatform.value = opt },
                        label = { Text(opt) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }

        if (downloadsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Empty History",
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "History Is Empty",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Completed downloads appear here. Filter or search them instantly.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(downloadsList, key = { it.id }) { item ->
                    HistoryItemCard(
                        item = item,
                        onPlay = {
                            val f = File(item.filePath)
                            if (f.exists()) {
                                onPlayMedia(item.filePath)
                            } else {
                                Toast.makeText(context, "Underlying folder/file not found!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onShare = {
                            shareFile(context, File(item.filePath), item.fileName)
                        },
                        onDelete = {
                            viewModel.deleteDownload(item, deleteFileFromDisk = true)
                        },
                        onReDownload = {
                            viewModel.triggerDownload(item.url)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(
    item: DownloadItem,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
    onReDownload: () -> Unit
) {
    val dateString = remember(item.timestamp) {
        val formatter = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        formatter.format(Date(item.timestamp))
    }

    val sizeString = remember(item.fileSize) {
        val size = item.fileSize
        when {
            size <= 0 -> "0 B"
            size < 1024 -> "$size B"
            size < 1024 * 1024 -> "${String.format("%.1f", size / 1024.0)} KB"
            else -> "${String.format("%.1f", size / (1024.0 * 1024.0))} MB"
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { if (item.status == "Completed") onPlay() },
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Platform visual icon acts as thumbnail
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(
                        getPlatformBadgeColor(item.platform).copy(alpha = 0.1f),
                        RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (item.platform) {
                        "YouTube" -> Icons.Default.PlayArrow
                        "Instagram" -> Icons.Default.VideoCameraBack
                        "Twitter" -> Icons.Default.ChatBubble
                        "Facebook" -> Icons.Default.Group
                        else -> Icons.Default.FileDownload
                    },
                    contentDescription = item.platform,
                    tint = getPlatformBadgeColor(item.platform),
                    modifier = Modifier.size(28.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.platform,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = getPlatformBadgeColor(item.platform)
                    )

                    Text(
                        text = dateString,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$sizeString | ${item.status}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = if (item.status == "Completed") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )

                    // Action buttons overlay row
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (item.status == "Completed") {
                            IconButton(onClick = onShare, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share Saved File",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        if (item.status == "Failed") {
                            IconButton(onClick = onReDownload, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Re-download",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Local History",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun shareFile(context: Context, file: File, fileName: String) {
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist on disk!", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",  // Configure provider properly in manifest or share
            file
        )
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "video/mp4"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Downloaded Media via:"))
    } catch (e: Exception) {
        // Fallback share as text if URI provider is not configured
        val textIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "QuickSave AI downloaded: $fileName. File path: ${file.absolutePath}")
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(textIntent, "Share path as info:"))
    }
}
