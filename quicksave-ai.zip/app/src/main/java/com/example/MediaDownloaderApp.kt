package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.DownloadRepository

class MediaDownloaderApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { DownloadRepository(this, database.downloadDao()) }

    override fun onCreate() {
        super.onCreate()
    }
}
