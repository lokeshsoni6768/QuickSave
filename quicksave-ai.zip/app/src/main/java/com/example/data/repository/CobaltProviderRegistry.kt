package com.example.data.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.TimeUnit
import android.util.Log

object CobaltProviderRegistry {

    data class ProviderInfo(
        val url: String,
        val status: String = "UNCHECKED", // "HEALTHY", "DEGRADED", "OFFLINE", "AUTH_REQUIRED", "UNCHECKED"
        val dnsStatus: String = "UNCHECKED",
        val connectivityStatus: String = "UNCHECKED",
        val apiAvailabilityStatus: String = "UNCHECKED",
        val lastResponseCode: Int = -1,
        val lastResponseBody: String = "",
        val lastError: String = ""
    )

    private val _providers = MutableStateFlow<List<ProviderInfo>>(
        listOf(
            ProviderInfo("https://cobalt.audiostatus.in/"),
            ProviderInfo("https://cobalt-api.lulee.top/"),
            ProviderInfo("https://cobalt.api.rybnd.com/"),
            ProviderInfo("https://co.wuk.sh/"),
            ProviderInfo("https://api.cobalt.tools/"),
            ProviderInfo("https://api.cobalt.rip/")
        )
    )
    val providers: StateFlow<List<ProviderInfo>> = _providers.asStateFlow()

    private val _activeProvider = MutableStateFlow<String>("None Selected")
    val activeProvider: StateFlow<String> = _activeProvider.asStateFlow()

    private val _lastApiResponse = MutableStateFlow<String>("No requests sent yet in this session.")
    val lastApiResponse: StateFlow<String> = _lastApiResponse.asStateFlow()

    fun setActiveProvider(url: String) {
        _activeProvider.value = url
    }

    fun setLastApiResponse(response: String) {
        _lastApiResponse.value = response
    }

    fun updateProvider(info: ProviderInfo) {
        _providers.value = _providers.value.map {
            if (it.url == info.url) info else it
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    /**
     * Test DNS resolution, connectivity, and API availability for all stored providers.
     */
    fun runAllDiagnosticChecks() {
        // Clone the list of URLs to avoid concurrent modification issues
        val urls = _providers.value.map { it.url }
        for (url in urls) {
            performHealthCheck(url)
        }
    }

    /**
     * Performs comprehensive health checks on a provider, testing:
     * 1. DNS resolution
     * 2. Connectivity (TCP connection)
     * 3. API availability (GET / or API responses)
     */
    fun performHealthCheck(providerUrl: String): ProviderInfo {
        var dns = "FAILED"
        var conn = "FAILED"
        var api = "FAILED"
        var status = "OFFLINE"
        var lastCode = -1
        var lastBody = ""
        var lastErr = ""

        // 1. DNS Check
        val host = try { URL(providerUrl).host } catch (e: Exception) { null }
        if (host != null) {
            try {
                val addr = InetAddress.getByName(host)
                dns = "OK (${addr.hostAddress})"
            } catch (e: Exception) {
                lastErr = "DNS resolution failed: ${e.message}"
                dns = "FAILED (${e.message ?: "Unknown resolve error"})"
            }
        } else {
            dns = "ERROR (Invalid URL format)"
        }

        // 2. Connectivity Check (If DNS is healthy)
        if (!dns.startsWith("FAILED") && !dns.startsWith("ERROR")) {
            val request = Request.Builder()
                .url(providerUrl)
                .get()
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string() ?: ""
                    conn = "OK (Status: $lastCode)"

                    // 3. API Availability Check
                    if (lastCode in 200..499) {
                        api = "OK"
                        status = "HEALTHY"

                        // Check for known JWT configurations or Turnstile shields
                        if (lastBody.contains("jwt.missing") || lastBody.contains("error.api.auth") || lastCode == 401) {
                            status = "AUTH_REQUIRED"
                            lastErr = "JWT session restriction detected (error.api.auth.jwt.missing)"
                        }
                    } else {
                        api = "FAILED"
                        status = "DEGRADED"
                        lastErr = "Server responded with error status $lastCode"
                    }
                }
            } catch (e: Exception) {
                conn = "FAILED (${e.message})"
                api = "FAILED (${e.message})"
                status = "OFFLINE"
                lastErr = "Connection failed: ${e.message}"
            }
        } else {
            conn = "SKIPPED (DNS unresolved)"
            api = "SKIPPED (DNS unresolved)"
            status = "OFFLINE"
            lastErr = "Aborted: Hostname dns failed to resolve."
        }

        val updatedInfo = ProviderInfo(
            url = providerUrl,
            status = status,
            dnsStatus = dns,
            connectivityStatus = conn,
            apiAvailabilityStatus = api,
            lastResponseCode = lastCode,
            lastResponseBody = lastBody,
            lastError = lastErr
        )
        updateProvider(updatedInfo)
        return updatedInfo
    }
}
