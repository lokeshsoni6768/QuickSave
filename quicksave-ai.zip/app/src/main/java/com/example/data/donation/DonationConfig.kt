package com.example.data.donation

/**
 * Global configuration file for QuickSave AI Donation & Branding Details.
 * Admins can modify these values to instantly update the UPI details and brand name.
 */
object DonationConfig {
    // Admin editable payment information
    const val DEVELOPED_BY = "IGI STUDIO INDIA"
    const val DONATION_UPI_ID = "igistudio@nyes"
    const val DONATION_ACCOUNT_NAME = "IGI STUDIO INDIA Support"
    const val DEFAULT_DONATION_AMOUNT = "100"
    
    // Aesthetic strings
    const val BRANDING_LABEL = "Developed By : $DEVELOPED_BY"
    const val SUPPORT_MESSAGE = "Support Independent Development"
    const val DONATION_SUBTITLE = "Keep our services fast, clean, and 100% ad-free forever."
}
