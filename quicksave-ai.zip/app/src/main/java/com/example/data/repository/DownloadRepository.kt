package com.example.data.repository

import android.content.Context
import androidx.work.*
import com.example.data.local.DownloadDao
import com.example.data.model.DownloadItem
import com.example.worker.DownloadWorker
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.util.Calendar

class DownloadRepository(
    private val context: Context,
    private val downloadDao: DownloadDao
) {
    val allDownloads: Flow<List<DownloadItem>> = downloadDao.getAllDownloads()

    suspend fun getDownloadById(id: Int): DownloadItem? {
        return downloadDao.getDownloadById(id)
    }

    suspend fun insert(item: DownloadItem): Long {
        return downloadDao.insert(item)
    }

    suspend fun update(item: DownloadItem) {
        downloadDao.update(item)
    }

    suspend fun delete(item: DownloadItem) {
        downloadDao.delete(item)
    }

    suspend fun deleteById(id: Int) {
        downloadDao.deleteById(id)
    }

    private fun normalizeUrl(url: String): String {
        var cleanUrl = url.trim()
        val lower = cleanUrl.lowercase()
        if (lower.contains("instagram.com") || lower.contains("instagr.am")) {
            try {
                if (cleanUrl.contains("instagr.am")) {
                    cleanUrl = cleanUrl.replace("instagr.am", "instagram.com")
                }
                if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                    cleanUrl = "https://$cleanUrl"
                } else if (cleanUrl.startsWith("http://")) {
                    cleanUrl = "https://" + cleanUrl.substring(7)
                }

                val uriWithoutQuery = cleanUrl.substringBefore("?")
                var domainAndPath = uriWithoutQuery.substringAfter("https://")
                
                if (domainAndPath.startsWith("instagram.com")) {
                    domainAndPath = "www.$domainAndPath"
                }

                var cleanPath = domainAndPath.substringAfter("www.instagram.com")
                while (cleanPath.contains("//")) {
                    cleanPath = cleanPath.replace("//", "/")
                }

                if (cleanPath.startsWith("/reels/")) {
                    cleanPath = "/reel/" + cleanPath.substring(7)
                }

                if (!cleanPath.endsWith("/")) {
                    cleanPath += "/"
                }

                return "https://www.instagram.com$cleanPath"
            } catch (e: Exception) {
                return url
            }
        }
        return url
    }

    suspend fun enqueueDownload(url: String, wifiOnly: Boolean = false): Int {
        val normalizedUrl = normalizeUrl(url)
        val platform = detectPlatform(normalizedUrl)
        val title = generateIntelligentTitle(platform, normalizedUrl)
        val fileName = generateIntelligentFileName(platform)
        val folderName = platform // "Instagram", "YouTube", etc.
        
        // Define directory inside internal or external app storage for reliable saving
        val directFolder = File(context.getExternalFilesDir(null), "QuickSave_AI/$folderName")
        if (!directFolder.exists()) {
            directFolder.mkdirs()
        }
        val fileTarget = File(directFolder, fileName)
        val filePath = fileTarget.absolutePath

        val item = DownloadItem(
            url = normalizedUrl,
            platform = platform,
            title = title,
            fileName = fileName,
            filePath = filePath,
            fileSize = 0L,
            timestamp = System.currentTimeMillis(),
            status = "Pending",
            progress = 0,
            thumbnailUrl = null
        )

        val insertedId = insert(item).toInt()

        // Configure network constraints
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .build()

        // Create work request
        val workRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(
                workDataOf(
                    "DOWNLOAD_ID" to insertedId
                )
            )
            .setConstraints(constraints)
            .addTag("DownloadWork_${insertedId}")
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "Download_Task_${insertedId}",
            ExistingWorkPolicy.REPLACE,
            workRequest
        )

        return insertedId
    }

    fun detectPlatform(url: String): String {
        val lower = url.lowercase()
        return when {
            lower.contains("instagram.com") || lower.contains("instagr.am") -> "Instagram"
            lower.contains("youtube.com") || lower.contains("youtu.be") -> "YouTube"
            lower.contains("facebook.com") || lower.contains("fb.watch") || lower.contains("fb.com") -> "Facebook"
            lower.contains("twitter.com") || lower.contains("x.com") -> "Twitter"
            lower.contains("pinterest.com") || lower.contains("pin.it") -> "Pinterest"
            lower.contains("vimeo.com") -> "Vimeo"
            lower.contains("dailymotion.com") || lower.contains("dai.ly") -> "Dailymotion"
            lower.contains("threads.net") -> "Threads"
            lower.contains("reddit.com") -> "Reddit"
            else -> "Other"
        }
    }

    private fun generateIntelligentTitle(platform: String, url: String): String {
        val cleanUrl = url.substringBefore("?").substringAfter("://").trim()
        val truncated = if (cleanUrl.length > 25) cleanUrl.take(25) + "..." else cleanUrl
        return "$platform Post - $truncated"
    }

    private fun generateIntelligentFileName(platform: String): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val timeInMillis = System.currentTimeMillis() % 1000000L
        return "${platform}_Video_${year}_${String.format("%03d", timeInMillis)}.mp4"
    }
}
