package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val url: String,
    val platform: String,
    val title: String,
    val fileName: String,
    val filePath: String,
    val fileSize: Long,
    val timestamp: Long,
    val status: String, // "Pending", "Downloading", "Completed", "Failed"
    val progress: Int, // 0 to 100
    val thumbnailUrl: String? = null
)
