package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.DownloadItem
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DownloadViewModel
import kotlinx.coroutines.flow.collectLatest
import java.io.File
import java.util.regex.Pattern

class MainActivity : ComponentActivity() {

    private val viewModel: DownloadViewModel by viewModels()

    // Launcher for Android 13+ Notification Permissions
    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                // Permission granted
            } else {
                Toast.makeText(this, "Notifications disabled. Download status won't be shown.", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()

        // Handle Share Targets instantly
        handleSharedIntent(intent)

        // Request runtime permissions if Android 13+
        checkNotificationPermission()

        setContent {
            val darkThemeMode by viewModel.darkThemeEnabled.collectAsState()

            MyApplicationTheme(darkTheme = darkThemeMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var showSplash by remember { mutableStateOf(true) }

                    if (showSplash) {
                        SplashScreen(onSplashFinished = { showSplash = false })
                    } else {
                        MainNavigationHost(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
    }

    private fun handleSharedIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type

        if (Intent.ACTION_SEND == action && type != null) {
            if ("text/plain" == type) {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                val extractedUrl = extractUrlFromText(sharedText)
                if (extractedUrl != null) {
                    // Trigger download background worker
                    viewModel.triggerDownload(extractedUrl)
                    
                    // Show confirmation overlay and exit immediately, keeping them inside their original app!
                    Toast.makeText(this, "QuickSave AI: Link Received. Save started silently!", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    Toast.makeText(this, "QuickSave AI: No valid video URL found in shared content.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Extraction helper to find URLs within raw shared strings
    private fun extractUrlFromText(text: String): String? {
        val urlRegex = "https?://[\\w\\d:#@%/;\\$()~_?\\+-=\\\\\\.&]+"
        val pattern = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(text)
        if (matcher.find()) {
            return matcher.group(0)
        }
        return null
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(permission)
            }
        }
    }
}

// Custom simple navigation routes
enum class MainTabs(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Default.Home),
    DOWNLOADS("downloads", "Downloading", Icons.Default.ArrowDownward),
    HISTORY("history", "History", Icons.Default.History),
    SETTINGS("settings", "Settings", Icons.Default.Settings)
}

@Composable
fun MainNavigationHost(viewModel: DownloadViewModel) {
    var activeTab by remember { mutableStateOf(MainTabs.HOME) }
    var activeVideoPathToDeleteOrPlay by remember { mutableStateOf<String?>(null) }
    var subScreenRoute by remember { mutableStateOf<String?>(null) } // "donation", "about", or "player"
    val context = LocalContext.current

    // Gather toasts and status outputs from ViewModel
    LaunchedEffect(key1 = true) {
        viewModel.uiMessage.collectLatest { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (subScreenRoute == null) {
                NavigationBar(
                    windowInsets = WindowInsets.navigationBars,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    MainTabs.values().forEach { tab ->
                        NavigationBarItem(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (subScreenRoute != null) {
                when (subScreenRoute) {
                    "donation" -> {
                        DonationScreen(
                            onNavigateBack = { subScreenRoute = null }
                        )
                    }
                    "about" -> {
                        AboutScreen(
                            onNavigateBack = { subScreenRoute = null }
                        )
                    }
                    "debug" -> {
                        CobaltDebugScreen(
                            onNavigateBack = { subScreenRoute = null }
                        )
                    }
                    "player" -> {
                        val path = activeVideoPathToDeleteOrPlay ?: ""
                        MediaPlayerScreen(
                            videoPath = path,
                            onNavigateBack = { subScreenRoute = null },
                            onDeleteFile = {
                                try {
                                    val f = File(path)
                                    if (f.exists()) {
                                        f.delete()
                                    }
                                    Toast.makeText(context, "Deleted media file from disk.", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                                subScreenRoute = null
                            }
                        )
                    }
                }
            } else {
                // Normal standard main tabs
                val screenModifier = Modifier.padding(innerPadding).statusBarsPadding()
                when (activeTab) {
                    MainTabs.HOME -> {
                        HomeScreen(viewModel = viewModel, modifier = screenModifier)
                    }
                    MainTabs.DOWNLOADS -> {
                        DownloadsScreen(viewModel = viewModel, modifier = screenModifier)
                    }
                    MainTabs.HISTORY -> {
                        HistoryScreen(
                            viewModel = viewModel,
                            onPlayMedia = { path ->
                                activeVideoPathToDeleteOrPlay = path
                                subScreenRoute = "player"
                            },
                            modifier = screenModifier
                        )
                    }
                    MainTabs.SETTINGS -> {
                        SettingsScreen(
                            viewModel = viewModel,
                            onNavigateToDonation = { subScreenRoute = "donation" },
                            onNavigateToAbout = { subScreenRoute = "about" },
                            onNavigateToDebug = { subScreenRoute = "debug" },
                            modifier = screenModifier
                        )
                    }
                }
            }
        }
    }
}
